import React, { useState } from 'react';
import { CreatorDashboard } from './components/CreatorDashboard';
import { CreatorStorefront } from './components/CreatorStorefront';
import { Header } from './components/Header';
import { CartProvider } from './hooks/useCart';
import { MOCK_APPROVED_CREATOR, MOCK_PENDING_APPLICATIONS, MOCK_PRODUCTS } from './constants';
import { Product, Creator, CreatorStatus } from './types';
import { AdminDashboard } from './components/AdminDashboard';
import { CreatorApplicationForm } from './components/CreatorApplicationForm';
import { ApplicationStatus } from './components/ApplicationStatus';

export type View = 'STOREFRONT' | 'SELLER' | 'ADMIN';

const App: React.FC = () => {
  const [view, setView] = useState<View>('SELLER');
  const [products, setProducts] = useState<Product[]>(MOCK_PRODUCTS);
  const [creators, setCreators] = useState<Creator[]>([MOCK_APPROVED_CREATOR, ...MOCK_PENDING_APPLICATIONS]);
  
  // Simulate a "logged in" creator. Starts as null for the application flow.
  const [currentCreator, setCurrentCreator] = useState<Creator | null>(null);

  const addProduct = (product: Product) => {
    setProducts(prevProducts => [...prevProducts, { ...product, id: `prod-${Date.now()}` }]);
  };

  const handleApplicationSubmit = (details: { name: string; idNumber: string; telephoneNumber: string; businessCategory: string; mpesaNumber: string; bio: string; instagramHandle: string; }) => {
    const newCreator: Creator = {
      id: `creator-${Date.now()}`,
      handle: `@${details.name.toLowerCase().replace(/\s+/g, '')}`,
      avatarUrl: `https://picsum.photos/seed/${Date.now()}/100/100`,
      status: CreatorStatus.PENDING,
      ...details,
    };
    setCreators(prev => [...prev, newCreator]);
    setCurrentCreator(newCreator);
  };
  
  const handleApprove = (creatorId: string) => {
    setCreators(creators.map(c => c.id === creatorId ? {...c, status: CreatorStatus.APPROVED} : c));
  };
  
  const handleReject = (creatorId: string) => {
     setCreators(creators.map(c => c.id === creatorId ? {...c, status: CreatorStatus.REJECTED, rejectionReason: 'Incomplete or unclear information provided.'} : c));
  };

  const renderContent = () => {
    switch(view) {
      case 'ADMIN':
        const pending = creators.filter(c => c.status === CreatorStatus.PENDING);
        return <AdminDashboard applications={pending} onApprove={handleApprove} onReject={handleReject} />;
      case 'STOREFRONT':
        // For simplicity, storefront always shows the first approved creator's shop
        return <CreatorStorefront creator={MOCK_APPROVED_CREATOR} products={products} />;
      case 'SELLER':
      default:
        if (!currentCreator) {
          return <CreatorApplicationForm onSubmit={handleApplicationSubmit} />;
        }
        switch(currentCreator.status) {
          case CreatorStatus.APPROVED:
            return <CreatorDashboard creator={currentCreator} products={products} addProduct={addProduct} />;
          case CreatorStatus.PENDING:
          case CreatorStatus.REJECTED:
            return <ApplicationStatus creator={currentCreator} />;
          default:
             return <CreatorApplicationForm onSubmit={handleApplicationSubmit} />;
        }
    }
  };

  return (
    <CartProvider>
      <div className="min-h-screen bg-gray-50 text-gray-800">
        <Header 
          view={view} 
          setView={setView}
          creatorName={currentCreator?.name || 'Creator'} 
        />
        <main className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto">
          {renderContent()}
        </main>
        <footer className="text-center p-4 text-xs text-gray-500 mt-8">
            <p>Shop254 &copy; {new Date().getFullYear()}. Jenga biashara yako. </p>
        </footer>
      </div>
    </CartProvider>
  );
};

export default App;