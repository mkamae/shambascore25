import React from 'react';
import { Creator, CreatorStatus } from '../types';
import { ClockIcon } from './icons/ClockIcon';
import { XCircleIcon } from './icons/XCircleIcon';

interface ApplicationStatusProps {
    creator: Creator;
}

export const ApplicationStatus: React.FC<ApplicationStatusProps> = ({ creator }) => {
    if (creator.status === CreatorStatus.PENDING) {
        return (
            <div className="max-w-2xl mx-auto text-center bg-white p-8 rounded-lg shadow-md">
                <ClockIcon className="mx-auto h-12 w-12 text-yellow-500" />
                <h1 className="mt-4 text-2xl font-bold text-gray-900">Application Pending</h1>
                <p className="mt-2 text-md text-gray-600">
                    Asante for applying, {creator.name.split(' ')[0]}! Your application is currently under review.
                </p>
                <p className="mt-1 text-sm text-gray-500">We'll notify you via email once it's approved. This usually takes less than 24 hours.</p>
            </div>
        );
    }

    if (creator.status === CreatorStatus.REJECTED) {
         return (
            <div className="max-w-2xl mx-auto text-center bg-white p-8 rounded-lg shadow-md">
                <XCircleIcon className="mx-auto h-12 w-12 text-red-500" />
                <h1 className="mt-4 text-2xl font-bold text-gray-900">Application Not Approved</h1>
                <p className="mt-2 text-md text-gray-600">
                   Unfortunately, we were unable to approve your application at this time.
                </p>
                {creator.rejectionReason && (
                    <p className="mt-2 text-sm text-gray-500 bg-red-50 p-3 rounded-md">
                        <strong>Reason:</strong> {creator.rejectionReason}
                    </p>
                )}
                 <p className="mt-4 text-sm text-gray-500">Please contact support if you believe this is an error.</p>
            </div>
        );
    }
    
    return null; // Should not happen if used correctly
};
