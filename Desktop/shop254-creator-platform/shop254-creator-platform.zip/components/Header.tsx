import React, { useState } from 'react';
import { useCart } from '../hooks/useCart';
import { Cart } from './Cart';
import { UserIcon } from './icons/UserIcon';
import { StoreIcon } from './icons/StoreIcon';
import { CartIcon } from './icons/CartIcon';
import { ShieldCheckIcon } from './icons/ShieldCheckIcon';
import { View } from '../App';

interface HeaderProps {
  view: View;
  setView: (view: View) => void;
  creatorName: string;
}

export const Header: React.FC<HeaderProps> = ({ view, setView, creatorName }) => {
  const { state: cartState } = useCart();
  const [isCartOpen, setIsCartOpen] = useState(false);
  
  const cartItemCount = cartState.items.reduce((acc, item) => acc + item.quantity, 0);
  
  const getButtonClass = (buttonView: View) => {
    return view === buttonView 
      ? 'bg-teal-500 text-white shadow' 
      : 'text-gray-600 hover:bg-gray-200';
  };

  return (
    <>
      <header className="bg-white shadow-sm sticky top-0 z-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex-shrink-0">
              <span className="text-xl font-bold text-teal-600">Shop254</span>
            </div>
            
            {/* View Toggle */}
            <div className="hidden sm:block">
                <div className="flex items-center space-x-1 bg-gray-100 p-1 rounded-full">
                    <button onClick={() => setView('SELLER')} className={`px-3 py-1.5 text-sm font-medium rounded-full flex items-center space-x-2 ${getButtonClass('SELLER')}`}>
                        <UserIcon className="h-5 w-5" />
                        <span>Seller</span>
                    </button>
                    <button onClick={() => setView('STOREFRONT')} className={`px-3 py-1.5 text-sm font-medium rounded-full flex items-center space-x-2 ${getButtonClass('STOREFRONT')}`}>
                        <StoreIcon className="h-5 w-5" />
                        <span>Storefront</span>
                    </button>
                    <button onClick={() => setView('ADMIN')} className={`px-3 py-1.5 text-sm font-medium rounded-full flex items-center space-x-2 ${getButtonClass('ADMIN')}`}>
                        <ShieldCheckIcon className="h-5 w-5" />
                        <span>Admin</span>
                    </button>
                </div>
            </div>

            <div className="flex items-center">
              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 rounded-full text-gray-500 hover:text-gray-700 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500"
                aria-label={`Cart with ${cartItemCount} items`}
              >
                <span className="sr-only">Open cart</span>
                <CartIcon className="h-6 w-6" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-red-500 text-xs font-medium text-white">
                    {cartItemCount}
                  </span>
                )}
              </button>
            </div>
          </div>
          {/* Mobile View Toggle */}
          <div className="sm:hidden pb-3">
              <div className="flex items-center justify-center space-x-1 bg-gray-100 p-1 rounded-full">
                  <button onClick={() => setView('SELLER')} className={`flex-1 justify-center py-1.5 text-xs font-medium rounded-full flex items-center space-x-2 ${getButtonClass('SELLER')}`}>
                      <UserIcon className="h-5 w-5" />
                      <span>Seller</span>
                  </button>
                  <button onClick={() => setView('STOREFRONT')} className={`flex-1 justify-center py-1.5 text-xs font-medium rounded-full flex items-center space-x-2 ${getButtonClass('STOREFRONT')}`}>
                      <StoreIcon className="h-5 w-5" />
                      <span>Store</span>
                  </button>
                   <button onClick={() => setView('ADMIN')} className={`flex-1 justify-center py-1.5 text-xs font-medium rounded-full flex items-center space-x-2 ${getButtonClass('ADMIN')}`}>
                      <ShieldCheckIcon className="h-5 w-5" />
                      <span>Admin</span>
                  </button>
              </div>
          </div>
        </div>
      </header>
      <Cart isOpen={isCartOpen} setIsOpen={setIsCartOpen} />
    </>
  );
};